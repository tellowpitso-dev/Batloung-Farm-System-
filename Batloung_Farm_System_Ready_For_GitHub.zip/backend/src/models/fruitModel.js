// backend/src/models/fruitModel.js
const db = require('../database/db');

const FruitModel = {
    async getAll() {
        const [fruits] = await db.query('SELECT * FROM fruits ORDER BY fruit_id ASC');
        // Attach packaging pricing and stock to each fruit
        for (let fruit of fruits) {
            const [pricing] = await db.query(
                'SELECT packaging_size, wholesale_price, selling_price FROM fruit_pricing WHERE fruit_id = ?',
                [fruit.fruit_id]
            );
            const [stock] = await db.query(
                'SELECT packaging_size, available_quantity FROM stock WHERE fruit_id = ?',
                [fruit.fruit_id]
            );
            fruit.pricing = pricing;
            fruit.stock = stock;
        }
        return fruits;
    },

    async getById(id) {
        const [rows] = await db.query('SELECT * FROM fruits WHERE fruit_id = ?', [id]);
        if (rows.length === 0) return null;
        const fruit = rows[0];

        const [pricing] = await db.query(
            'SELECT packaging_size, wholesale_price, selling_price FROM fruit_pricing WHERE fruit_id = ?',
            [id]
        );
        const [stock] = await db.query(
            'SELECT packaging_size, available_quantity FROM stock WHERE fruit_id = ?',
            [id]
        );
        fruit.pricing = pricing;
        fruit.stock = stock;
        return fruit;
    },

    async create({ fruit_name, description, status = 'AVAILABLE', prices = {} }) {
        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();

            const [result] = await connection.query(
                'INSERT INTO fruits (fruit_name, description, status) VALUES (?, ?, ?)',
                [fruit_name, description, status]
            );
            const fruitId = result.insertId;

            const sizes = ['SMALL', 'MEDIUM', 'LARGE'];
            for (const size of sizes) {
                const sp = (prices[size] && prices[size].selling_price) ? prices[size].selling_price : 0;
                const wp = (prices[size] && prices[size].wholesale_price) ? prices[size].wholesale_price : 0;
                await connection.query(
                    `INSERT INTO fruit_pricing (fruit_id, packaging_size, wholesale_price, selling_price)
                     VALUES (?, ?, ?, ?)`,
                    [fruitId, size, wp, sp]
                );
                await connection.query(
                    `INSERT INTO stock (fruit_id, packaging_size, available_quantity)
                     VALUES (?, ?, 0)`,
                    [fruitId, size]
                );
            }

            await connection.commit();
            return fruitId;
        } catch (err) {
            await connection.rollback();
            throw err;
        } finally {
            connection.release();
        }
    },

    async update(id, { fruit_name, description, status }) {
        const [result] = await db.query(
            'UPDATE fruits SET fruit_name = ?, description = ?, status = ? WHERE fruit_id = ?',
            [fruit_name, description, status, id]
        );
        return result.affectedRows > 0;
    },

    async getStockQuantities() {
        const query = `
            SELECT 
                s.stock_id,
                f.fruit_id,
                f.fruit_name,
                s.packaging_size,
                s.available_quantity,
                fp.selling_price,
                fp.wholesale_price,
                CASE 
                    WHEN s.available_quantity < 20 THEN 'LOW_STOCK'
                    ELSE 'HEALTHY'
                END as stock_status
            FROM stock s
            JOIN fruits f ON s.fruit_id = f.fruit_id
            LEFT JOIN fruit_pricing fp ON s.fruit_id = fp.fruit_id AND s.packaging_size = fp.packaging_size
            ORDER BY f.fruit_name, FIELD(s.packaging_size, 'SMALL', 'MEDIUM', 'LARGE')
        `;
        const [rows] = await db.query(query);
        return rows;
    },

    async getLowStock(threshold = 20) {
        const query = `
            SELECT 
                s.stock_id,
                f.fruit_id,
                f.fruit_name,
                s.packaging_size,
                s.available_quantity,
                fp.selling_price
            FROM stock s
            JOIN fruits f ON s.fruit_id = f.fruit_id
            LEFT JOIN fruit_pricing fp ON s.fruit_id = fp.fruit_id AND s.packaging_size = fp.packaging_size
            WHERE s.available_quantity < ?
            ORDER BY s.available_quantity ASC
        `;
        const [rows] = await db.query(query, [threshold]);
        return rows;
    }
};

module.exports = FruitModel;
