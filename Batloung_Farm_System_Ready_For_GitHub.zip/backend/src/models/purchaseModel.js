// backend/src/models/purchaseModel.js
const db = require('../database/db');

const PurchaseModel = {
    async getAll() {
        const query = `
            SELECT 
                p.purchase_id,
                p.purchase_date,
                p.total_amount,
                s.supplier_id,
                s.business_name as supplier_name,
                s.province,
                COUNT(pi.purchase_detail_id) as total_items,
                SUM(pi.quantity) as total_boxes
            FROM purchases p
            JOIN suppliers s ON p.supplier_id = s.supplier_id
            LEFT JOIN purchase_details pi ON p.purchase_id = pi.purchase_id
            GROUP BY p.purchase_id
            ORDER BY p.purchase_date DESC
        `;
        const [rows] = await db.query(query);
        return rows;
    },

    async getById(id) {
        const [purchases] = await db.query(
            `SELECT p.*, s.business_name as supplier_name, s.province, s.phone 
             FROM purchases p 
             JOIN suppliers s ON p.supplier_id = s.supplier_id 
             WHERE p.purchase_id = ?`,
            [id]
        );
        if (purchases.length === 0) return null;

        const purchase = purchases[0];
        const [items] = await db.query(
            `SELECT pi.*, f.fruit_name 
             FROM purchase_details pi 
             JOIN fruits f ON pi.fruit_id = f.fruit_id 
             WHERE pi.purchase_id = ?`,
            [id]
        );
        purchase.items = items;
        return purchase;
    },

    async recordPurchase({ supplier_id, purchase_date, items }) {
        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();

            let total_amount = 0;
            for (const item of items) {
                total_amount += Number(item.quantity) * Number(item.unit_cost);
            }

            const [purchaseResult] = await connection.query(
                `INSERT INTO purchases (supplier_id, purchase_date, total_amount)
                 VALUES (?, ?, ?)`,
                [supplier_id, purchase_date || new Date(), total_amount]
            );
            const purchase_id = purchaseResult.insertId;

            for (const item of items) {
                const { fruit_id, packaging_size, quantity, unit_cost } = item;

                await connection.query(
                    `INSERT INTO purchase_details (purchase_id, fruit_id, packaging_size, quantity, unit_cost)
                     VALUES (?, ?, ?, ?, ?)`,
                    [purchase_id, fruit_id, packaging_size.toUpperCase(), quantity, unit_cost]
                );

                // Atomic stock increase
                await connection.query(
                    `INSERT INTO stock (fruit_id, packaging_size, available_quantity)
                     VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE available_quantity = available_quantity + ?`,
                    [fruit_id, packaging_size.toUpperCase(), quantity, quantity]
                );
            }

            await connection.commit();
            return { purchase_id, total_amount };
        } catch (err) {
            await connection.rollback();
            throw err;
        } finally {
            connection.release();
        }
    }
};

module.exports = PurchaseModel;
