// backend/src/models/reportModel.js
const db = require('../database/db');

const ReportModel = {
    // 1. Top 5 most frequently sold fruits
    async getTopFiveFruits() {
        const query = `
            SELECT 
                f.fruit_id,
                f.fruit_name,
                f.status,
                SUM(sd.quantity) as total_boxes_sold,
                COUNT(DISTINCT sd.sale_id) as total_orders,
                SUM(sd.quantity * sd.unit_price) as total_revenue
            FROM sales_details sd
            JOIN fruits f ON sd.fruit_id = f.fruit_id
            JOIN sales s ON sd.sale_id = s.sale_id
            WHERE s.order_status != 'CANCELLED'
            GROUP BY f.fruit_id, f.fruit_name, f.status
            ORDER BY total_boxes_sold DESC
            LIMIT 5
        `;
        const [rows] = await db.query(query);
        return rows;
    },

    // 2. Total sales revenue during a specified date range
    async getSalesRevenue(startDate, endDate) {
        const query = `
            SELECT 
                COUNT(s.sale_id) as total_sales_count,
                COALESCE(SUM(s.total_amount), 0) as total_revenue,
                COALESCE(SUM(p.amount_paid), 0) as total_collected,
                COALESCE(SUM(s.total_amount) - SUM(p.amount_paid), 0) as outstanding_receivables,
                MIN(s.sale_date) as from_date,
                MAX(s.sale_date) as to_date
            FROM sales s
            LEFT JOIN payments p ON s.sale_id = p.sale_id
            WHERE DATE(s.sale_date) BETWEEN ? AND ?
              AND s.order_status != 'CANCELLED'
        `;
        const [rows] = await db.query(query, [startDate, endDate]);
        return rows[0];
    },

    // 3. Vendor who has purchased the highest number of boxes
    async getTopVendor() {
        const query = `
            SELECT 
                v.vendor_id,
                v.vendor_code,
                v.vendor_name,
                v.phone_number,
                v.location,
                SUM(sd.quantity) as total_boxes_purchased,
                COUNT(DISTINCT s.sale_id) as total_orders,
                SUM(s.total_amount) as total_spent,
                v.outstanding_balance
            FROM vendors v
            JOIN sales s ON v.vendor_id = s.vendor_id
            JOIN sales_details sd ON s.sale_id = sd.sale_id
            WHERE s.order_status != 'CANCELLED'
            GROUP BY v.vendor_id, v.vendor_code, v.vendor_name, v.phone_number, v.location, v.outstanding_balance
            ORDER BY total_boxes_purchased DESC
            LIMIT 1
        `;
        const [rows] = await db.query(query);
        return rows[0] || null;
    },

    // 4. Current stock levels for each fruit and packaging size
    async getStockLevels() {
        const query = `
            SELECT 
                f.fruit_id,
                f.fruit_name,
                s.packaging_size,
                s.available_quantity,
                fp.selling_price,
                fp.wholesale_price,
                (s.available_quantity * fp.selling_price) as stock_valuation,
                CASE 
                    WHEN s.available_quantity < 20 THEN 'LOW_STOCK'
                    WHEN s.available_quantity BETWEEN 20 AND 50 THEN 'MODERATE'
                    ELSE 'PLENTIFUL'
                END as status_indicator
            FROM stock s
            JOIN fruits f ON s.fruit_id = f.fruit_id
            LEFT JOIN fruit_pricing fp ON s.fruit_id = fp.fruit_id AND s.packaging_size = fp.packaging_size
            ORDER BY f.fruit_name ASC, FIELD(s.packaging_size, 'SMALL', 'MEDIUM', 'LARGE')
        `;
        const [rows] = await db.query(query);
        return rows;
    }
};

module.exports = ReportModel;
