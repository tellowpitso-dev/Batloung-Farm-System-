// backend/src/models/salesModel.js
const db = require('../database/db');

// Maseru Depot Coordinates
const DEPOT_LAT = -29.3100;
const DEPOT_LNG = 27.4800;

function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Number((R * c).toFixed(2));
}

const SalesModel = {
    async getAll(vendorId = null) {
        let query = `
            SELECT 
                s.sale_id,
                s.sale_date,
                s.order_status,
                s.payment_status,
                s.total_amount,
                s.distance_km,
                s.eta_minutes,
                v.vendor_id,
                v.vendor_code,
                v.vendor_name,
                v.phone_number,
                v.location,
                v.latitude as vendor_lat,
                v.longitude as vendor_lng,
                v.outstanding_balance,
                COUNT(sd.sale_detail_id) as total_items,
                COALESCE(SUM(sd.quantity), 0) as total_boxes,
                COALESCE(SUM(p.amount_paid), 0) as total_paid
            FROM sales s
            JOIN vendors v ON s.vendor_id = v.vendor_id
            LEFT JOIN sales_details sd ON s.sale_id = sd.sale_id
            LEFT JOIN payments p ON s.sale_id = p.sale_id
        `;
        const params = [];
        if (vendorId) {
            query += ' WHERE s.vendor_id = ? ';
            params.push(vendorId);
        }
        query += ' GROUP BY s.sale_id ORDER BY s.sale_date DESC';
        const [rows] = await db.query(query, params);
        return rows;
    },

    async getById(id) {
        const [sales] = await db.query(
            `SELECT s.*, v.vendor_name, v.vendor_code, v.phone_number, v.location, v.latitude, v.longitude, v.outstanding_balance
             FROM sales s
             JOIN vendors v ON s.vendor_id = v.vendor_id
             WHERE s.sale_id = ?`,
            [id]
        );
        if (sales.length === 0) return null;

        const sale = sales[0];
        const [items] = await db.query(
            `SELECT sd.*, f.fruit_name
             FROM sales_details sd
             JOIN fruits f ON sd.fruit_id = f.fruit_id
             WHERE sd.sale_id = ?`,
            [id]
        );
        const [payments] = await db.query('SELECT * FROM payments WHERE sale_id = ? ORDER BY payment_date ASC', [id]);
        sale.items = items;
        sale.payments = payments;
        return sale;
    },

    async createSale({ vendor_id, items, payment_method, amount_paid = 0, initial_status = 'PENDING' }) {
        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();

            // 1. Verify vendor
            const [vendorRows] = await connection.query('SELECT * FROM vendors WHERE vendor_id = ?', [vendor_id]);
            if (vendorRows.length === 0) {
                throw new Error('VENDOR_NOT_FOUND');
            }
            const vendor = vendorRows[0];

            // 2. Validate stock quantities atomically with FOR UPDATE locks
            const validatedItems = [];
            let total_amount = 0;

            for (const item of items) {
                const { fruit_id, packaging_size, quantity } = item;
                const size = packaging_size.toUpperCase();
                const qty = Number(quantity);

                const [stockRows] = await connection.query(
                    'SELECT available_quantity FROM stock WHERE fruit_id = ? AND packaging_size = ? FOR UPDATE',
                    [fruit_id, size]
                );

                const currentStock = stockRows.length > 0 ? stockRows[0].available_quantity : 0;
                if (currentStock < qty) {
                    const [fruitRow] = await connection.query('SELECT fruit_name FROM fruits WHERE fruit_id = ?', [fruit_id]);
                    const fruitName = fruitRow.length > 0 ? fruitRow[0].fruit_name : `Fruit #${fruit_id}`;
                    const err = new Error(`INSUFFICIENT_STOCK: ${fruitName} (${size}). Requested: ${qty}, Available: ${currentStock}`);
                    err.code = 'INSUFFICIENT_STOCK';
                    throw err;
                }

                const [pricingRows] = await connection.query(
                    'SELECT selling_price FROM fruit_pricing WHERE fruit_id = ? AND packaging_size = ?',
                    [fruit_id, size]
                );
                const unit_price = pricingRows.length > 0 ? Number(pricingRows[0].selling_price) : 0;
                const line_total = unit_price * qty;
                total_amount += line_total;

                validatedItems.push({
                    fruit_id,
                    packaging_size: size,
                    quantity: qty,
                    unit_price,
                    currentStock
                });
            }

            // 3. Compute distance and ETA
            const vendorLat = Number(vendor.latitude) || DEPOT_LAT;
            const vendorLng = Number(vendor.longitude) || DEPOT_LNG;
            const distance_km = calculateHaversineDistance(DEPOT_LAT, DEPOT_LNG, vendorLat, vendorLng);
            const eta_minutes = Math.max(5, Math.round(distance_km * 2.8));

            // 4. Determine initial payment status
            const paid = Number(amount_paid) || 0;
            let payment_status = 'UNPAID';
            if (paid >= total_amount) {
                payment_status = 'PAID';
            } else if (paid > 0) {
                payment_status = 'PARTIALLY_PAID';
            }

            // 5. Insert sale record
            const [saleResult] = await connection.query(
                `INSERT INTO sales (vendor_id, sale_date, order_status, payment_status, total_amount, distance_km, eta_minutes)
                 VALUES (?, NOW(), ?, ?, ?, ?, ?)`,
                [vendor_id, initial_status, payment_status, total_amount, distance_km, eta_minutes]
            );
            const sale_id = saleResult.insertId;

            // 6. Insert items and decrement stock only if approved/out for delivery
            for (const item of validatedItems) {
                await connection.query(
                    `INSERT INTO sales_details (sale_id, fruit_id, packaging_size, quantity, unit_price)
                     VALUES (?, ?, ?, ?, ?)`,
                    [sale_id, item.fruit_id, item.packaging_size, item.quantity, item.unit_price]
                );

                if (initial_status !== 'PENDING') {
                    await connection.query(
                        `UPDATE stock 
                         SET available_quantity = available_quantity - ? 
                         WHERE fruit_id = ? AND packaging_size = ?`,
                        [item.quantity, item.fruit_id, item.packaging_size]
                    );
                }
            }

            // 7. Record payment if any
            if (paid > 0 && payment_method) {
                await connection.query(
                    `INSERT INTO payments (sale_id, payment_date, amount_paid, payment_method, notes)
                     VALUES (?, NOW(), ?, ?, 'Initial payment on order placement')`,
                    [sale_id, paid, payment_method]
                );
            }

            // 8. Update vendor balance
            const unpaidAmount = Math.max(0, total_amount - paid);
            if (unpaidAmount > 0) {
                await connection.query(
                    'UPDATE vendors SET outstanding_balance = outstanding_balance + ? WHERE vendor_id = ?',
                    [unpaidAmount, vendor_id]
                );
            }

            await connection.commit();
            return {
                sale_id,
                total_amount,
                payment_status,
                distance_km,
                eta_minutes
            };
        } catch (err) {
            await connection.rollback();
            throw err;
        } finally {
            connection.release();
        }
    },

    async updateOrderStatus(id, newStatus) {
        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();

            const [saleRows] = await connection.query('SELECT order_status FROM sales WHERE sale_id = ? FOR UPDATE', [id]);
            if (saleRows.length === 0) throw new Error('SALE_NOT_FOUND');

            const oldStatus = saleRows[0].order_status;
            if (oldStatus === 'PENDING' && (newStatus === 'APPROVED' || newStatus === 'READY_FOR_COLLECTION' || newStatus === 'OUT_FOR_DELIVERY')) {
                // Deduct stock upon approval
                const [items] = await connection.query('SELECT fruit_id, packaging_size, quantity FROM sales_details WHERE sale_id = ?', [id]);
                for (const item of items) {
                    await connection.query(
                        `UPDATE stock 
                         SET available_quantity = GREATEST(0, available_quantity - ?) 
                         WHERE fruit_id = ? AND packaging_size = ?`,
                        [item.quantity, item.fruit_id, item.packaging_size]
                    );
                }
            }

            await connection.query('UPDATE sales SET order_status = ? WHERE sale_id = ?', [newStatus, id]);
            await connection.commit();
            return true;
        } catch (err) {
            await connection.rollback();
            throw err;
        } finally {
            connection.release();
        }
    }
};

module.exports = SalesModel;
