// backend/src/models/supplierModel.js
const db = require('../database/db');

const SupplierModel = {
    async getAll() {
        const [rows] = await db.query('SELECT * FROM suppliers ORDER BY supplier_id ASC');
        return rows;
    },

    async getById(id) {
        const [rows] = await db.query('SELECT * FROM suppliers WHERE supplier_id = ?', [id]);
        return rows[0] || null;
    },

    async create({ business_name, contact_person, phone, province, address }) {
        const [result] = await db.query(
            `INSERT INTO suppliers (business_name, contact_person, phone, province, address)
             VALUES (?, ?, ?, ?, ?)`,
            [business_name, contact_person, phone, province, address]
        );
        return result.insertId;
    },

    async update(id, { business_name, contact_person, phone, province, address }) {
        const [result] = await db.query(
            `UPDATE suppliers 
             SET business_name = ?, contact_person = ?, phone = ?, province = ?, address = ?
             WHERE supplier_id = ?`,
            [business_name, contact_person, phone, province, address, id]
        );
        return result.affectedRows > 0;
    },

    async delete(id) {
        // Business constraint check: cannot delete if purchase records exist
        const [purchases] = await db.query('SELECT purchase_id FROM purchases WHERE supplier_id = ? LIMIT 1', [id]);
        if (purchases.length > 0) {
            throw new Error('CANNOT_DELETE_SUPPLIER_WITH_PURCHASES');
        }
        const [result] = await db.query('DELETE FROM suppliers WHERE supplier_id = ?', [id]);
        return result.affectedRows > 0;
    }
};

module.exports = SupplierModel;
