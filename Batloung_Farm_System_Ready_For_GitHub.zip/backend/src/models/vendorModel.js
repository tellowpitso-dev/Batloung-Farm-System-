// backend/src/models/vendorModel.js
const db = require('../database/db');

const VendorModel = {
    async getAll() {
        const query = `
            SELECT 
                v.*,
                COALESCE(SUM(s.total_amount), 0) as total_purchases,
                COALESCE(SUM(p.amount_paid), 0) as total_paid,
                COALESCE(v.outstanding_balance, 0) as current_balance
            FROM vendors v
            LEFT JOIN sales s ON v.vendor_id = s.vendor_id
            LEFT JOIN payments p ON s.sale_id = p.sale_id
            GROUP BY v.vendor_id
            ORDER BY v.vendor_id ASC
        `;
        const [rows] = await db.query(query);
        return rows;
    },

    async getById(id) {
        const [rows] = await db.query('SELECT * FROM vendors WHERE vendor_id = ?', [id]);
        return rows[0] || null;
    },

    async search(term) {
        const wildcard = `%${term}%`;
        const [rows] = await db.query(
            `SELECT * FROM vendors 
             WHERE vendor_name LIKE ? OR phone_number LIKE ? OR location LIKE ?
             ORDER BY vendor_name ASC`,
            [wildcard, wildcard, wildcard]
        );
        return rows;
    },

    async create({ vendor_code, vendor_name, phone_number, location, latitude, longitude }) {
        const [result] = await db.query(
            `INSERT INTO vendors (vendor_code, vendor_name, phone_number, location, latitude, longitude, outstanding_balance)
             VALUES (?, ?, ?, ?, ?, ?, 0.00)`,
            [vendor_code, vendor_name, phone_number, location, latitude || -29.3100, longitude || 27.4800]
        );
        return result.insertId;
    },

    async update(id, { vendor_name, phone_number, location, latitude, longitude }) {
        const [result] = await db.query(
            `UPDATE vendors 
             SET vendor_name = ?, phone_number = ?, location = ?, latitude = ?, longitude = ?
             WHERE vendor_id = ?`,
            [vendor_name, phone_number, location, latitude, longitude, id]
        );
        return result.affectedRows > 0;
    },

    async getBalances() {
        const query = `
            SELECT 
                vendor_id,
                vendor_code,
                vendor_name,
                phone_number,
                location,
                outstanding_balance,
                CASE 
                    WHEN outstanding_balance = 0 THEN 'SETTLED'
                    ELSE 'HAS_OUTSTANDING'
                END as balance_status
            FROM vendors
            ORDER BY outstanding_balance DESC
        `;
        const [rows] = await db.query(query);
        return rows;
    }
};

module.exports = VendorModel;
